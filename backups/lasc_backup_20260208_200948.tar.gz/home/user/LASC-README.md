# LASC OS v1.0
## Sistema Operacional Mobile Linux

Desenvolvido por Luiz A. S. Corrêa  
Baseado em postmarketOS v25.12

---

## 📋 Especificações Técnicas

- **Versão:** 1.0
- **Kernel:** Linux 6.18.7-0-lts
- **Arquitetura:** x86_64
- **Interface:** Phosh (Mobile UI)
- **Espaço Total:** 3.6GB
- **Base:** postmarketOS v25.12 (Alpine Linux)
- **Data de Criação:** Fevereiro 2026

---

## 🎯 Visão do Projeto

O LASC OS é um sistema operacional mobile completo baseado em Linux, desenvolvido para rodar em smartphones reais. Oferece uma alternativa open source aos sistemas proprietários (Android, iOS), com foco em privacidade, customização e controle total do usuário.

---

## ⚡ Comandos Exclusivos do LASC OS

### Launcher e Menus
- **`android`** - Menu principal (launcher estilo Android)
- **`store`** - Loja de aplicativos interativa
- **`lasc-store`** - Hub central do sistema

### Informações do Sistema
- **`fetch`** - Informações estilizadas do sistema
- **`lasc-fetch`** - Versão completa
- **`info`** - Informações detalhadas
- **`lasc-info`** - Versão completa
- **`apps`** - Lista todos os apps instalados
- **`lasc-list`** - Versão completa

### Gerenciamento
- **`lasc-apps`** - Instalador interativo de aplicativos
- **`update`** / **`lasc-update`** - Atualizar sistema e pacotes
- **`lasc-dashboard`** - Dashboard inicial
- **`lasc-doctor`** - Diagnóstico completo
- **`lasc-clean`** - Limpeza e otimização
- **`about`** / **`lasc-about`** - Sobre o sistema
- **`lasc-backup`** - Backup de configurações

### Atalhos Úteis
- **`readme`** - Ver esta documentação
- **`espaço`** - Ver uso de disco
- **`memoria`** - Ver uso de RAM
- **`ll`** - Listar arquivos detalhado
- **`cls`** - Limpar tela

---

## 📱 Apps Disponíveis via lasc-apps

### COMUNICAÇÃO
- Firefox - Navegador web
- Telegram - Mensagens
- Geary - Email cliente
- Calls - Chamadas
- Chatty - SMS/MMS

### MÍDIA
- Lollypop - Player de música
- Celluloid - Player de vídeo
- Eye of GNOME - Visualizador de imagens

### PRODUTIVIDADE
- GNOME Text Editor - Editor de texto
- Calculator - Calculadora
- Calendar - Calendário
- Contacts - Contatos
- Clocks - Relógio/Alarmes
- Weather - Clima
- Evince - Leitor PDF

### DESENVOLVIMENTO
- Git - Controle de versão
- Python 3 + pip - Linguagem Python
- Node.js + npm - JavaScript runtime
- Vim - Editor avançado
- Htop - Monitor de processos

---

## 🚀 Como Usar

### Após Login
O dashboard aparece automaticamente mostrando status completo do sistema.

### Acessar Apps
```bash
android          # Abre menu principal
```

### Instalar Novos Apps
```bash
lasc-apps       # Instalador interativo
```

### Ver Apps Instalados
```bash
apps            # Lista com checkmarks
```

### Diagnóstico
```bash
lasc-doctor     # Verifica saúde do sistema
```

### Limpeza
```bash
lasc-clean      # Libera espaço
```

---

## 💻 Instalação em Hardware Real

### Dispositivos Suportados
- **PinePhone / PinePhone Pro** (~$150)
- **OnePlus 6 / 6T** (~R$600 usado)
- **Xiaomi Poco F1** (~R$500 usado)
- **Google Pixel 3a/3aXL**

### Processo de Instalação
```bash
pmbootstrap init
# Escolher dispositivo real
pmbootstrap install
pmbootstrap flasher flash_rootfs
```

---

## 🌟 Diferenciais

✅ **Privacidade Total** - Sem Google, sem tracking  
✅ **Open Source 100%** - Código aberto completo  
✅ **Customização Infinita** - Controle total  
✅ **Terminal Poderoso** - Acesso root completo  
✅ **12 Comandos Exclusivos** - Ferramentas únicas  

---

## 👨‍💻 Desenvolvedor

**Luiz A. S. Corrêa**  
Pinhais/PR, Brasil  
Fevereiro 2026

---

**LASC OS - Sistema Operacional Mobile Linux**  
*Privacidade, Liberdade, Controle*
